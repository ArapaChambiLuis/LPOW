
function TaxiRenault (tipoMotor, numeroPasajeros, carga, velocidad) { //objeto TaxiRenault
this.tipoMotor = tipoMotor; //valores
this.numeroPasajeros = numeroPasajeros;
this.carga = carga;
this.velocidad = velocidad;
}

TaxiRenault.prototype = {
fabricante: 'Renault, S.A.',// propiedades comunes
direccionFabricante: 'c/R, Paris',
getCapacidad: function () { if (tipoMotor == 'Diesel') { return 40;} else {return 35;} }, //metodos comunes
variarCarga: function (variacion) { this.carga = this.carga + variacion; },
variarVelocidad: function (variacion) { this.velocidad = this.velocidad + variacion; }
}

function ejemploObjetos() {
var taxi1 = new TaxiRenault(1, 4, 300, 90);
var taxi2 = new TaxiRenault(2, 6, 350, 80);
var taxi3 = new TaxiRenault(1, 5, 340, 110);
alert ('El fabricante del taxi 2 es ' + taxi2.fabricante + ' y la velocidad del taxi 2 es ' + taxi2.velocidad);
taxi2.variarVelocidad(-10);
alert ('El taxi 2 ha reducido su velocidad y ahora es ' + taxi2.velocidad);
}
